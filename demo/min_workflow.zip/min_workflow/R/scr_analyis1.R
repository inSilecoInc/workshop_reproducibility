# This script produces figure 1 and table 1

scr_part1 <- function() {
  # read data
  kam <- get_data()
  # or kam <- readRDS("data/w_51423.rds")
  # create figure 1
  ggplot(data = kam, aes(x = time, y = temp, group = station_name, 
    colour = station_name)) + 
    theme_minimal() +  
    geom_line()  
  # you can use it as is in a Rmd report or save it 
  ggsave("output/fig1.png")    
  
  # perform lm and write table
  get_tbl("output/tab1.rds",  formula = temp~wind_chill, data = kam)
  
  NULL
}

