# this function  perfom a linear model and save the coefficient table 
# x path of the file where the table is saved.
# ... arguments pass to `lm()`

get_tbl <- function(x, ...) {
  # extract test results that are stored in `coef`
  saveRDS(summary(lm(...))$coef, x)
}