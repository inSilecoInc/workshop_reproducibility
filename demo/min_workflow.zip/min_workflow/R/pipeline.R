pipeline <- function() {
  library(tidyverse)
  # creates first figure and first table 1
  cat("Running part 1...\n")
  scr_part1()
  cat("done!\n")
  
  invisible(NULL)
}