# data : data
# path : path where table will be stored.
#
create_tab1 <- function(data) {
  # extract test results that are stored in `coef`
  summary(lm(formula = temp~wind_chill, data = data))$coef
}