render_ms <- function(...) {
  rmarkdown::render("../ms/ms.Rmd")
}