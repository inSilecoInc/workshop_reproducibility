#' This function prepares data 
get_data <- function() {
  # may include data retrieval of remote databases, first processing (e.g. filtering) anonymisation of data that cannot be shared
  kam <- weather_dl(station_ids = 51423, start = "2018-02-01", end = "2018-04-01")
  
  # optionally you can save the object 
  saveRDS(kam, "data/w_51423.rds")
  kam 
}