# This script creates figure 1

create_fig1 <- function(kam) {
  # creates figure 1
  ggplot(data = kam, aes(x = time, y = temp, group = station_name, 
    colour = station_name)) + 
    theme_minimal() +  
    geom_line()
}

