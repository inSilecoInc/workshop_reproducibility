# Research compendium

Explain what this is and most importantly make an explicit reference to the paper/report.


## Installation 

Analyses were performed with [R, a free software environment for statistical computing and graphics](https://www.r-project.org/).

Requirements:

- R version >=3.2
- package tidyverse >= 1.3
- package rmarkdown >= 2.6
- package [weathercan](https://docs.ropensci.org/weathercan/index.html) >= 0.5
- package [targets](https://docs.ropensci.org/targets/articles/overview.html) >= 0.2

Detail instructions to install dependencies. 

```R
install.packages(c("tidyverse", "weathercan", "targets"))
```

## Organisation

- `data/`: includes input data.
- `R/`: includes R source code.
- `output/` includes code artefacts.
- `ms/` includes manuscript/report.


## How to use this research compendium

This compendium uses `targets`, the entire pipeline can be reproduce using:

```{R}
library(targets)
tar_make() 
```


### Last run 

The analysis were run for the last time under the following environment:

```R
R> sessionInfo()
R version 4.0.4 (2021-02-15)
Platform: x86_64-pc-linux-gnu (64-bit)
Running under: Debian GNU/Linux bullseye/sid

Matrix products: default
BLAS:   /usr/lib/x86_64-linux-gnu/openblas-pthread/libblas.so.3
LAPACK: /usr/lib/x86_64-linux-gnu/openblas-pthread/libopenblasp-r0.3.13.so

locale:
 [1] LC_CTYPE=en_CA.UTF-8       LC_NUMERIC=C              
 [3] LC_TIME=en_CA.UTF-8        LC_COLLATE=en_CA.UTF-8    
 [5] LC_MONETARY=en_CA.UTF-8    LC_MESSAGES=en_CA.UTF-8   
 [7] LC_PAPER=en_CA.UTF-8       LC_NAME=C                 
 [9] LC_ADDRESS=C               LC_TELEPHONE=C            
[11] LC_MEASUREMENT=en_CA.UTF-8 LC_IDENTIFICATION=C       

attached base packages:
[1] stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
[1] tarchetypes_0.1.0 targets_0.2.0    

loaded via a namespace (and not attached):
 [1] igraph_1.2.6      rstudioapi_0.13   magrittr_2.0.1    tidyselect_1.1.0 
 [5] R6_2.5.0          rlang_0.4.10      fansi_0.4.2       tools_4.0.4      
 [9] visNetwork_2.0.9  data.table_1.13.6 utf8_1.1.4        cli_2.3.1        
[13] withr_2.4.1       htmltools_0.5.1.1 ellipsis_0.3.1    yaml_2.2.1       
[17] assertthat_0.2.1  digest_0.6.27     tibble_3.1.0      lifecycle_1.0.0  
[21] crayon_1.4.1      processx_3.4.5    purrr_0.3.4       callr_3.5.1      
[25] fs_1.5.0          htmlwidgets_1.5.3 vctrs_0.3.6       ps_1.5.0         
[29] codetools_0.2-18  glue_1.4.2        compiler_4.0.4    pillar_1.5.0     
[33] jsonlite_1.7.2    pkgconfig_2.0.3  

```