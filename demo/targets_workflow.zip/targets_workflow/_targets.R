# _targets.R ==> pipeline/workflow
# See https://books.ropensci.org/targets/walkthrough.html#about-this-minimal-example
library(targets)
library(tarchetypes)
rsrc <- lapply(list.files("R", full.names = TRUE), source)
options(tidyverse.quiet = TRUE)
tar_option_set(packages = c("weathercan", "tidyverse"))
list(
  tar_target(data, get_data()),
  tar_target(tab1, create_tab1(data)),
  tar_target(fig1, create_fig1(data)),
  tar_render(report, "ms/ms.Rmd")
)
# tar_glimpse()